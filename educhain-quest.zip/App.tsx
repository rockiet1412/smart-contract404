
import React, { useState, useCallback, useMemo } from 'react';
import { GameState, Quest, QuestStatus, QuestType, View } from './types';
import { INITIAL_QUESTS, INITIAL_PLAYER_STATE } from './constants';
import Header from './components/Header';
import QuestBoard from './components/QuestBoard';
import QuestRunner from './components/QuestRunner';
import Inventory from './components/Inventory';
import Ledger from './components/Ledger';

export default function App() {
  const [gameState, setGameState] = useState<GameState>({
    player: INITIAL_PLAYER_STATE,
    quests: INITIAL_QUESTS,
    transactions: [],
    currentView: View.Quests,
    activeQuest: null,
  });

  const handleStartQuest = useCallback((questId: string) => {
    const questToStart = gameState.quests.find(q => q.id === questId);
    if (questToStart && questToStart.status === QuestStatus.Available) {
      setGameState(prev => ({
        ...prev,
        activeQuest: questToStart,
        currentView: View.Questing,
      }));
    }
  }, [gameState.quests]);

  const handleCompleteQuest = useCallback((questId: string, reward: { tokens: number; item?: string }) => {
    setGameState(prev => {
      const newTransactions = [...prev.transactions, {
        id: `0x${crypto.randomUUID().replace(/-/g, '')}`,
        questId: questId,
        description: `Reward for '${prev.quests.find(q => q.id === questId)?.title}'`,
        tokens: reward.tokens,
        item: reward.item,
        timestamp: new Date().toISOString(),
      }];
      
      const newQuests = prev.quests.map(q => 
        q.id === questId ? { ...q, status: QuestStatus.Completed } : q
      );

      const newInventory = reward.item ? [...prev.player.inventory, reward.item] : prev.player.inventory;
      
      return {
        ...prev,
        player: {
          ...prev.player,
          tokens: prev.player.tokens + reward.tokens,
          xp: prev.player.xp + 100, // Fixed XP for now
          inventory: newInventory,
        },
        quests: newQuests,
        transactions: newTransactions,
        activeQuest: null,
        currentView: View.Quests,
      };
    });
  }, []);
  
  const handleQuitQuest = useCallback(() => {
    setGameState(prev => ({ ...prev, activeQuest: null, currentView: View.Quests }));
  }, []);

  const handleNavigate = (view: View) => {
     if (gameState.currentView === View.Questing) return; // Prevent navigation while in a quest
     setGameState(prev => ({ ...prev, currentView: view }));
  };

  const currentViewComponent = useMemo(() => {
    switch (gameState.currentView) {
      case View.Inventory:
        return <Inventory items={gameState.player.inventory} />;
      case View.Ledger:
        return <Ledger transactions={gameState.transactions} />;
      case View.Questing:
        return gameState.activeQuest ? (
          <QuestRunner
            quest={gameState.activeQuest}
            onComplete={handleCompleteQuest}
            onQuit={handleQuitQuest}
          />
        ) : <QuestBoard quests={gameState.quests} onStartQuest={handleStartQuest} />;
      case View.Quests:
      default:
        return <QuestBoard quests={gameState.quests} onStartQuest={handleStartQuest} />;
    }
  }, [gameState.currentView, gameState.activeQuest, gameState.quests, gameState.player.inventory, gameState.transactions, handleStartQuest, handleCompleteQuest, handleQuitQuest]);


  return (
    <div className="min-h-screen bg-slate-900 font-sans text-slate-200 flex flex-col">
      <Header player={gameState.player} onNavigate={handleNavigate} currentView={gameState.currentView} />
      <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8">
        {currentViewComponent}
      </main>
      <footer className="text-center p-4 text-slate-500 text-xs border-t border-slate-800">
        EduChain Quest - Learning Gamified on the "Blockchain"
      </footer>
    </div>
  );
}
